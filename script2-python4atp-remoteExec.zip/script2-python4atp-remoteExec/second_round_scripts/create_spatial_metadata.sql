insert into user_sdo_geom_metadata select * from sdo_geom_metadata;
commit;

exit;