/* This is just to test that the connection worked*/
exit;