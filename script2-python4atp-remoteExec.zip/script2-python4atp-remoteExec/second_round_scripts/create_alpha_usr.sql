create user alpha identified by a1phaOffice1_;
grant dwrole to alpha;

exit;