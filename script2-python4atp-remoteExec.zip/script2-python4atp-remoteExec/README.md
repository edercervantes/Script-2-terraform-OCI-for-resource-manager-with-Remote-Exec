# Script-2-terraform-OCI-for-resource-manager-with-Remote-Exec

This folder is designed to accompany the Oracle Python4ATP HOL.

Instructions for running the folder

All you need to do is download the zip file from this repository.

-For debugging, see the following resources:

FAQ for the Oracle Cloud Infrastructure Terraform provider

Oracle Cloud Infrastructure Provider